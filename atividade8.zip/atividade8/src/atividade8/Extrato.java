package atividade8;

public class Extrato {
    private int id_tpo_transacao;
    private int id_transacao;
    private float valor_transacao;
    private String id_destinatario;
    private float saldo;
    private float extrato;

    public Extrato(int id_tpo_transacao, int id_transacao, float valor_transacao, String id_destinatario, float saldo, float extrato) {
        this.id_tpo_transacao = id_tpo_transacao;
        this.id_transacao = id_transacao;
        this.valor_transacao = valor_transacao;
        this.id_destinatario = id_destinatario;
        this.saldo = saldo;
        this.extrato = extrato;
        
    }
    
    public float consultar_saldo(float valor) {
        return saldo;
    }

    public float consultar_extrato(float valor) {
        return extrato;
    }

    // Getters and Setters
    public int getId_tpo_transacao() {
        return id_tpo_transacao;
    }

    public void setId_tpo_transacao(int id_tpo_transacao) {
        this.id_tpo_transacao = id_tpo_transacao;
    }

    public int getId_transacao() {
        return id_transacao;
    }

    public void setId_transacao(int id_transacao) {
        this.id_transacao = id_transacao;
    }

    public float getValor_transacao() {
        return valor_transacao;
    }

    public void setValor_transacao(float valor_transacao) {
        this.valor_transacao = valor_transacao;
    }

    public String getId_destinatario() {
        return id_destinatario;
    }

    public void setId_destinatario(String id_destinatario) {
        this.id_destinatario = id_destinatario;
    }
}