package atividade8;

import java.time.LocalDate;

public class Usuario {
    private String nome;
    private LocalDate data_nascimento;
    private String comp_endereco;
    private String email;
    private String senha;
    private String cadastral;
    private boolean excluir_cadastro;

    public Usuario(String nome, LocalDate data_nascimento, String comp_endereco, String email, String senha, String cadastral, boolean excluir_cadastro) {
        this.nome = nome;
        this.data_nascimento = data_nascimento;
        this.comp_endereco = comp_endereco;
        this.email = email;
        this.senha = senha;
        this.cadastral = cadastral;
        this.excluir_cadastro = excluir_cadastro;
    }

    // Getters and Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public LocalDate getData_nascimento() {
        return data_nascimento;
    }

    public void setData_nascimento(LocalDate data_nascimento) {
        this.data_nascimento = data_nascimento;
    }

    public String getComp_endereco() {
        return comp_endereco;
    }

    public void setComp_endereco(String comp_endereco) {
        this.comp_endereco = comp_endereco;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getCadastral() {
        return cadastral;
    }

    public void setCadastral(String cadastral) {
        this.cadastral = cadastral;
    }

    public boolean isExcluir_cadastro() {
        return excluir_cadastro;
    }

    public void setExcluir_cadastro(boolean excluir_cadastro) {
        this.excluir_cadastro = excluir_cadastro;
    }
}