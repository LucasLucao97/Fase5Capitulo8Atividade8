package atividade8;

import java.time.LocalDate;

public class Main {
	public static void main(String[] args) {
		// Create objects
		Documento documento = new Documento(1, 123456789, "CPF");
		Usuario usuario = new Usuario("John Doe", LocalDate.of(1990, 1, 1), "Rua Teste", "john.doe@example.com",
				"password", "12345678901", false);
		ContaBancaria contaBancaria = new ContaBancaria(1, "123456789", "0001", "Novo", 0, false);
		Cartao cartao = new Cartao("1234567890123456", LocalDate.of(2025, 1, 1), "Visa", 1, 100, 200);
		Extrato extrato = new Extrato(1, 1, 100, "12345678901", 1500, 2000);

		// Perform operations
		contaBancaria.deposito(1000);
		contaBancaria.saque(500);
		contaBancaria.analise_credito(false);
		extrato.consultar_saldo(1500);
		extrato.consultar_extrato(1500);
	}
}