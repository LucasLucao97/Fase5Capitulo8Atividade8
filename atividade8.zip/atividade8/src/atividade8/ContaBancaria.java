package atividade8;

public class ContaBancaria {
    private int id_banco;
    private String nr_conta;
    private String nr_agencia;
    private String novo_cadastro;
    private float saldo;
    private boolean excluir_cadastro;

    public ContaBancaria(int id_banco, String nr_conta, String nr_agencia, String novo_cadastro, float saldo,
                         boolean excluir_cadastro) {
        this.id_banco = id_banco;
        this.nr_conta = nr_conta;
        this.nr_agencia = nr_agencia;
        this.saldo = saldo;
        this.novo_cadastro = novo_cadastro;
        this.excluir_cadastro = excluir_cadastro;
    }

    // Getters and Setters
    public int getId_banco() {
        return id_banco;
    }

    public void setId_banco(int id_banco) {
        this.id_banco = id_banco;
    }

    public String getNr_conta() {
        return nr_conta;
    }

    public void setNr_conta(String nr_conta) {
        this.nr_conta = nr_conta;
    }

    public String getNr_agencia() {
        return nr_agencia;
    }

    public void setNr_agencia(String nr_agencia) {
        this.nr_agencia = nr_agencia;
    }

    public String getNovo_cadastro() {
        return novo_cadastro;
    }

    public void setNovo_cadastro(String novo_cadastro) {
        this.novo_cadastro = novo_cadastro;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public boolean isExcluir_cadastro() {
        return excluir_cadastro;
    }

    public void setExcluir_cadastro(boolean excluir_cadastro) {
        this.excluir_cadastro = excluir_cadastro;
    }

    public float deposito(float valor) {
        this.saldo += valor;
        return saldo;
    }

    public float saque(float valor) {
        if (this.saldo >= valor && valor > 0) {
            this.saldo -= valor;
        }
        return saldo;
    }

    public boolean analise_credito(boolean aprovado) {
        if (!aprovado) {
            System.out.println("Seu crédito foi recusado");
        } else {
            System.out.println("Seu crédito foi aprovado");
        }
        return aprovado;
    }
}