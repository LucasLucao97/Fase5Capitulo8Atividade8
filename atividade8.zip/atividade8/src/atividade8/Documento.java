package atividade8;

public class Documento {
    private int id_documento;
    private int nr_documento;
    private String tipo_documento;

    public Documento(int id_documento, int nr_documento, String tipo_documento) {
        this.id_documento = id_documento;
        this.nr_documento = nr_documento;
        this.tipo_documento = tipo_documento;
    }

    // Getters and Setters
    public int getId_documento() {
        return id_documento;
    }

    public void setId_documento(int id_documento) {
        this.id_documento = id_documento;
    }

    public int getNr_documento() {
        return nr_documento;
    }

    public void setNr_documento(int nr_documento) {
        this.nr_documento = nr_documento;
    }

    public String getTipo_documento() {
        return tipo_documento;
    }

    public void setTipo_documento(String tipo_documento) {
        this.tipo_documento = tipo_documento;
    }
}