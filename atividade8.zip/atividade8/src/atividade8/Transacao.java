package atividade8;

import java.time.LocalDate;

public class Transacao {
    private int id_transacao;
    private String id_destinatario;
    private LocalDate data_transacao;
    private float valor_transacao;
    private String id_tipo_transacao;
    private boolean status_transacao;
    private float deposito;
    private float transferencia;
    private float saque;
    private float ted;
    private float doc;
    private float pax;

    public Transacao(int id_transacao, String id_destinatario, LocalDate data_transacao, float valor_transacao, String id_tipo_transacao, boolean status_transacao, float deposito, float transferencia, float saque, float ted, float doc, float pax) {
        this.id_transacao = id_transacao;
        this.id_destinatario = id_destinatario;
        this.data_transacao = data_transacao;
        this.valor_transacao = valor_transacao;
        this.id_tipo_transacao = id_tipo_transacao;
        this.status_transacao = status_transacao;
        this.deposito = deposito;
        this.transferencia = transferencia;
        this.saque = saque;
        this.ted = ted;
        this.doc = doc;
        this.pax = pax;
    }

    // Getters and Setters
    public int getId_transacao() {
        return id_transacao;
    }

    public void setId_transacao(int id_transacao) {
        this.id_transacao = id_transacao;
    }

    public String getId_destinatario() {
        return id_destinatario;
    }

    public void setId_destinatario(String id_destinatario) {
        this.id_destinatario = id_destinatario;
    }

    public LocalDate getData_transacao() {
        return data_transacao;
    }

    public void setData_transacao(LocalDate data_transacao) {
        this.data_transacao = data_transacao;
    }

    public float getValor_transacao() {
        return valor_transacao;
    }

    public void setValor_transacao(float valor_transacao) {
        this.valor_transacao = valor_transacao;
    }

    public String getId_tipo_transacao() {
        return id_tipo_transacao;
    }

    public void setId_tipo_transacao(String id_tipo_transacao) {
        this.id_tipo_transacao = id_tipo_transacao;
    }

    public boolean isStatus_transacao() {
        return status_transacao;
    }

    public void setStatus_transacao(boolean status_transacao) {
        this.status_transacao = status_transacao;
    }

    public float getDeposito() {
        return deposito;
    }

    public void setDeposito(float deposito) {
        this.deposito = deposito;
    }

    public float getTransferencia() {
        return transferencia;
    }

    public void setTransferencia(float transferencia) {
        this.transferencia = transferencia;
    }

    public float getSaque() {
        return saque;
    }

    public void setSaque(float saque) {
        this.saque = saque;
    }

    public float getTed() {
        return ted;
    }

    public void setTed(float ted) {
        this.ted = ted;
    }

    public float getDoc() {
        return doc;
    }

    public void setDoc(float doc) {
        this.doc = doc;
    }

    public float getPax() {
        return pax;
    }

    public void setPax(float pax) {
        this.pax = pax;
    }
}