package atividade8;

import java.time.LocalDate;

public class Cartao {
    private String numero_cartao;
    private LocalDate data_validade;
    private String id_bandeira;
    private int id_po_cartao;
    private float pg_debito;
    private float pg_credito;

    public Cartao(String numero_cartao, LocalDate data_validade, String id_bandeira, int id_po_cartao, float pg_debito, float pg_credito) {
        this.numero_cartao = numero_cartao;
        this.data_validade = data_validade;
        this.id_bandeira = id_bandeira;
        this.id_po_cartao = id_po_cartao;
        this.pg_debito = pg_debito;
        this.pg_credito = pg_credito;
    }

    // Getters and Setters
    public String getNumero_cartao() {
        return numero_cartao;
    }

    public void setNumero_cartao(String numero_cartao) {
        this.numero_cartao = numero_cartao;
    }

    public LocalDate getData_validade() {
        return data_validade;
    }

    public void setData_validade(LocalDate data_validade) {
        this.data_validade = data_validade;
    }

    public String getId_bandeira() {
        return id_bandeira;
    }

    public void setId_bandeira(String id_bandeira) {
        this.id_bandeira = id_bandeira;
    }

    public int getId_po_cartao() {
        return id_po_cartao;
    }

    public void setId_po_cartao(int id_po_cartao) {
        this.id_po_cartao = id_po_cartao;
    }

    public float getPg_debito() {
        return pg_debito;
    }

    public void setPg_debito(float pg_debito) {
        this.pg_debito = pg_debito;
    }

    public float getPg_credito() {
        return pg_credito;
    }

    public void setPg_credito(float pg_credito) {
        this.pg_credito = pg_credito;
    }
}